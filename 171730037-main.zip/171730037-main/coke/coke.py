def coke(amount_due):
    amount_due=int(amount_due)
    coins = int(input("Insert Coin: "))
    if coins != 25 and coins !=  10 and coins !=  5:
        print("Invalid coin. Insert 25,10 or 5 cents")
        print(f"Amount Due: {amount_due}")
        return coke(amount_due)
    amount_due = amount_due - coins
    if amount_due <= 0:
        return print(f"Change Owed: {- amount_due}")
    else:
        print(f"Amount Due: {amount_due}")
        return coke(amount_due)


coke(50)
