import re
months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]

def outdated(mnths):
    date = input("Date: ")
    if "/" in date and "," not in date:
        date = re.split(r"/", date)
        date = [int(i) for i in date]
        if date[0] > 12 or date[1] > 31:
            return outdated(mnths)
        else:
            ans = [date[2], date[0], date[1]]
            ans = "-".join(map(str, ans))
            print(ans)
            return date
    elif "," in date:
        date = re.split(r",? ", date)
        if date[0] not in mnths or :
            return outdated(mnths)
        else:
            date[0] = mnths.index(date[0]) + 1
            ans = [date[2], date[0], date[1]]
            ans = "-".join(map(str, ans))
            print(ans)
            return ans

outdated(months)
