def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(s):
    consonant ="ABCDEFGHIJKLMNÑOPQRSTUVWXYZ"
    numbers = "1234567890"
    s= s.upper()
    if s[0] not in consonant and s[1] not in consonant:
        return False
    elif len(s) < 2 or len(s) > 6:
        return False
    elif (any(char not in numbers and char not in consonant for char in s)):
        return False
    for char in s:
        if char in numbers:
            if char == "0":
                return False
            else:
                for i in s[s.index(char):]:
                    if i in consonant:
                        return False
    else:
        return True
main()
