MIMES ={".gif": "image/gif",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".pdf": "application/pdf",
            ".txt": "text/plain",
            ".zip": "application/zip"}

def extensions(MIME):
    file = input("File name: ")
    ext = "." + file.split(".")[-1].lower().strip()
    if ext in MIME:
        return MIME.get(str(ext))
    else:
        return "application/octet-stream"

print(extensions(MIMES))
