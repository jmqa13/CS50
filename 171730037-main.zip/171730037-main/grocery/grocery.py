def grocery():
    gr_store = {}
    while True:
        try:
            item = input("").upper()
            if not gr_store.get(item):
                gr_store[item] = 1
            else: gr_store[item] = (gr_store.get(item) + 1)
        except EOFError:
            break
    for key,value in sorted(gr_store.items()):
        print(f"{value} {key}")



grocery()
