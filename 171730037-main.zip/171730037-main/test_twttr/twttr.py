
def main():
    words = input("twttr word: ")
    print(shorten(words))


def shorten(word):
    vocals = "aeiouAEIOU"
    output_= ""
    for char in word:
        if char not in vocals:
            output_ += char
    return output_

if __name__ == "__main__":
    main()
    