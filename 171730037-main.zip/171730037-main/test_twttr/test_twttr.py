import twttr

def test_uppercase():
    assert "W R TH WRLD, W R TH CHLDRN" == twttr.shorten("WE ARE THE WORLD, WE ARE THE CHILDREN")

def test_lowercase():
    assert "w r th wrld, w r th chldrn" == twttr.shorten("we are the world, we are the children")

def  test_varietychar():
    assert "93849SDCGHK'¡ÑÑP`D````++" == twttr.shorten("93849SDCGHK'¡ÑÑP`D````++") 
