caps = input("Enter a higher case text: ")
print(caps.lower())
