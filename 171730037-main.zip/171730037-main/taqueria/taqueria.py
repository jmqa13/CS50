menu = {
    "Baja Taco": 4.25,
    "Burrito": 7.50,
    "Bowl": 8.50,
    "Nachos": 11.00,
    "Quesadilla": 8.50,
    "Super Burrito": 8.50,
    "Super Quesadilla": 9.50,
    "Taco": 3.00,
    "Tortilla Salad": 8.00
}
def order(menu_):
    order_ = []
    while True:
        try:
            item = input("Item: ").title()
            if item not in menu_:
                continue
            order_.append(menu_.get(item))
            print(f"${sum(order_):.2f}")
        except EOFError:
            break
order(menu)
