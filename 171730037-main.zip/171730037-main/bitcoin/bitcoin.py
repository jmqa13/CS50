import sys
import requests


try:
    n = float(sys.argv[1])

    request = requests.get("https://api.coindesk.com/v1/bpi/currentprice.json")
    data = request.json()
    bitcoin_price =((data["bpi"]["USD"]).get("rate_float"))*n
    bitcoin_price =f"${bitcoin_price:,.4f}"
    print(bitcoin_price)
except requests.RequestException:
    sys.exit("There was an error in the request")
except IndexError:
    sys.exit("Missing command-line argument")
except ValueError:
    sys.exit("Command-line argument is not a number")
