import sys

def scourgify():
    try:
        if len(sys.argv) < 3:
            sys.exit("Too few command-line arguments")
        elif len(sys.argv) > 3:
            sys.exit("Too many command-line arguments")
        with open(sys.argv[1]) as before:
            with open (sys.argv[2], "w") as after:
                next(before)
                for line in before:
                    line = line.replace('"', '').strip().strip().split(",")
                    after.write(",".join(([line[1], line[0], line[2],]))+"\n")
    except FileNotFoundError:
        sys.exit("Could not read invalid_file.csv")

scourgify()
