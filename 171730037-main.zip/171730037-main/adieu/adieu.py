def adieu():
    names = []
    try:
        while True:
            name = input("Name: ")
            names.append(name)
    except EOFError:
        if len(names) == 1:
            print(f"Adieu, adieu, to {names[0]}")
        else:
            print(f"Adieu, adieu, to {', '.join(names[:-1])}, and {names[-1]}")
adieu()
