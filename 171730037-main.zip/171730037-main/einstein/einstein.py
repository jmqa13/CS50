def Einstein():
    c =  int(300000000)
    m = int(input("m: "))
    E = m*c**2
    return f"E:{E}"

print(Einstein())
