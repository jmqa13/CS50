text = input("Introduce a text: ")
def playback(string):
    x = string.split()
    x = "...".join(x)
    return x

print(playback(text))
