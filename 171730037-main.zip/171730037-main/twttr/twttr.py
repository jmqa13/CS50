def twttr():
    vocals = "aeiouAEIOU"
    output_= ""
    input_= input("Input: ")
    for char in input_:
        if char not in vocals:
            output_ += char
    print(output_)
    return output_

twttr()
