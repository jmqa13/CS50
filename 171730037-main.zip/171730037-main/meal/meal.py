def main():
    meal = input("What time is it? ")
    hour = (convert(meal))
    if 0 <= hour <=8:
        return print("breakfast time")
    if 12 <= hour <= 13:
        return print("lunch time")
    if 18 <= hour <= 19:
        return print("dinner time")



def convert(time):
    time = time.split(":")
    minutes = int(time[1])/60
    time = int(time[0]) + minutes
    return time




if __name__ == "__main__":
    main()
