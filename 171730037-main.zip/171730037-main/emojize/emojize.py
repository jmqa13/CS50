import emoji
def emojizing():
    text = input("Input: ")
    print(emoji.emojize(text,language="alias"))

emojizing()
