def bank():
    greeting = str(input("Greeting: "))
    greeting = greeting.lower().strip()
    if "hello" in greeting:
        if greeting[0] == "h" and greeting[1] == "e" and greeting[2] == "l" and greeting[3] == "l" and greeting[4] == "o":
            money = "$0"
        elif greeting[0] == "h":
            money = "$20"
        else: money = "$100"
    elif "h" == greeting[0]:
        money = "$20"
    else: money = "$100"
    return money

print(bank())

