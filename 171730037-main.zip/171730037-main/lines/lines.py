import sys

if len(sys.argv) == 1:
    sys.exit("Too few command-line arguments ")
elif len(sys.argv) > 2:
    sys.exit("Too many command-line arguments ")
elif sys.argv[1][-3:] != ".py":
    sys.exit("Not a Python file ")

def lines():
    with open(sys.argv[1],"r") as file:
        count = 0
        for line in file:
            if line.strip() == "":
               continue
            elif line.strip()[0] == "#" :
                continue
            else: count += 1
        print(count)
        return count

lines()    
