import random
def game():
    while True:
        try:
            level = int(input("Level: "))
            while True:
                if level < 0:
                    raise ValueError
                else:
                    ans = random.randint(0,level)
                    while True:
                        try:
                            guess = int(input("Guess: "))
                            if guess < ans:
                                print("too small!")
                            elif guess > ans:
                                print("too large!")
                            else:
                                return (print("Just right!"))
                        except ValueError:
                            continue
        except ValueError:
            continue

game()
