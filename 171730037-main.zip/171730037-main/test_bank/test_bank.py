import bank

def test_hello():
    assert bank.value("hElLo, hI, hello") == 0
def test_not_hello_but_h():
    assert bank.value("Hi,HELlo") == 20
def test_not_hello_neither_h():
    assert bank.value("Bro, How you doin") == 100
