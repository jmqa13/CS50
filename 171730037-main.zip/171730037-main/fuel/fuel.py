import math
def fuel(top):
    fraction =(input("Fraction: "))
    fraction =(fraction.split("/"))
    try:
        fraction[0] = int(fraction[0])
        fraction[1] = int(fraction[1])
        if fraction[0] > fraction[1]:
            raise ValueError
        if fraction[1] == 0:
            raise ZeroDivisionError

        ans = round(fraction[0]/fraction[1]*100)
        if ans  == 0 or ans == 1:
            print("E")
            return "E"
        if ans == 99 or ans == 100:
            print("F")
            return "F"
        else:
            print(f"{ans}%")
            return f"{ans}%"
    except ValueError:
        return fuel(top)
    except ZeroDivisionError:
        return fuel(top)

fuel(4)
