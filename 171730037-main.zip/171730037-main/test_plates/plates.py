def main():
    plate = str(input("Plate: "))
    ans = is_valid(plate)
    print(ans)

def is_valid(s):
    consonant ="ABCDEFGHIJKLMNÑOPQRSTUVWXYZ"
    numbers = "1234567890"
    s= s.upper()
    if s[0] == "0":
        return False
    elif s[0] not in consonant and s[1] not in consonant:
        return False
    elif len(s) < 2 or len(s) > 6:
        return False
    elif for char in s:
        if char in numbers:
            if any(char in consonant for char in s[char:]):
                return False


    else:
        return True
if __name__ == "__main__":
    main()

