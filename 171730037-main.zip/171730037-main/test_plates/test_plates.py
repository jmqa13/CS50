from plates import is_valid

def test_nochar():
    assert False == is_valid("")
def test_non_cons_first():
    assert False == is_valid("C5S0")
def test_0f_first_number():
    assert False == is_valid("CS05")
def test_toolong():
    assert False == is_valid("CS50000")
def test_tooshort():
    assert False == is_valid("C")
def test_CS50():
    assert True == is_valid("CS50")
def test_fullcons():
    assert True == is_valid("CSSO00")
