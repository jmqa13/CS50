import re


def convert(text):
    text = text.replace(":)", "\U0001F642").replace(":(", "\U0001F641")
    return(text)
def main():
    inp = input("WTRITE SOMTEHING HAPPY OR SAD: ")
    return(convert(inp))

print(main())
