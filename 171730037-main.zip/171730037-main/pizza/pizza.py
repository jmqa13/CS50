from tabulate import tabulate
import sys

def pizza():
    try:
        if len(sys.argv) < 2:
            sys.exit("Too few command-line arguments")
        elif len(sys.argv) > 2:
            sys.exit("Too many command-line arguments")
        elif sys.argv[1][-4:] != ".csv":
            sys.exit("Not a CSV file")
        else:
            with open(sys.argv[1]) as file:
                menu=[]
                for line in file:
                    line = line.strip().split(",")
                    menu.append(line)
                print(tabulate(menu, headers= "firstrow",tablefmt="grid"))
    except FileNotFoundError:
        sys.exit("File does not exist")

pizza()
