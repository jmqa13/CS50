def camel():
    name = input("camelCase: ")
    snake_case_name = ""

    for char in name:
        if char.isupper():
            snake_case_name += "_" + char.lower()
        else:
            snake_case_name += char

    return f"snake_case: {snake_case_name}"

print(camel())

