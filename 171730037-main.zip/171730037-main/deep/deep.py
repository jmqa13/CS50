def deep():
    x = (input("What is the Answer to the Great Question of Life, the Universe, and Everything? "))
    x = x.lower().strip()
    if x == "42" or x == "forty two" or x == "forty-two":
        ans = "Yes"
    else:
        ans = "No"
    return ans

print(deep())
