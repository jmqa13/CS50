data = str(input("Expression: "))
result = float(eval(data))
print(result)
