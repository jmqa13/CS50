import random


def main():
    while True:
        try:
            _level_= get_level()
            questions = 0
            right = 0

            while questions < 10:

                x = int(generate_integer(_level_))
                y = int(generate_integer(_level_))

                answer = x + y
                attempts = 0
                while attempts < 3:
                    try:
                        user_answer = int(input(f"{x} + {y} = "))
                        if user_answer == answer:
                            right += 1
                            break
                        else:
                            print("EEE")
                            attempts += 1
                    except ValueError:
                        print("EEE")
                        attempts += 1
                        continue

                if attempts == 3:
                    print(f"{x} + {y} = {answer}")

                questions += 1

            return print(f"Score: {right}")

        except ValueError:
            continue


def get_level():
    try:
        digits = int(input("Level: "))
        if digits not in [1,2,3]:
            raise ValueError
        else: return digits
    except ValueError:
        return get_level()

def generate_integer(level):
    if level not in [1,2,3]:
        raise ValueError
    if level == 1:
        return random.randint(0,9)
    elif level == 2:
        return random.randint(10,99)
    elif level == 3:
        return random.randint(100,999)

if __name__ == "__main__":
    main()
